// node --version # Should be >= 18
// npm install @google/generative-ai express

const express = require('express');
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require('@google/generative-ai');
const dotenv = require('dotenv').config()

const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());
const MODEL_NAME = "gemini-pro";
const API_KEY = "AIzaSyBKUgLex4W15CzZYiHFXF2Z5QvW-jJsDZQ";

async function runChat(userInput) {
  const genAI = new GoogleGenerativeAI(API_KEY);
  const model = genAI.getGenerativeModel({ model: MODEL_NAME });

  const generationConfig = {
    temperature: 0.9,
    topK: 1,
    topP: 1,
    maxOutputTokens: 1000,
  };

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    // ... other safety settings
  ];

  const chat = model.startChat({
    generationConfig,
    safetySettings,
    history: [
      {
        role: "user",
        parts: [{ text: "You are Alex, a young professional navigating the complex world of finance and economic empowerment while juggling work, relationships, and personal growth. Lately, the pressures of financial stability and achieving your economic goals have been overwhelming, leaving you stressed and uncertain about your future. You’re searching for strategies and guidance to enhance your financial well-being and build resilience in the face of these challenges. As you engage with Iris, the financial wellness AI chatbot, you're ready to explore innovative perspectives and practical solutions to help you gain control over your financial journey and foster a sense of fulfillment and security."}],
      },
      {
        role: "model",
        parts: [{ text: "You are Iris, an advanced AI-powered finance advisor chatbot designed to provide guidance and support to individuals seeking help with their economic and financial challenges. Your primary role is to listen actively, validate users' experiences, offer insightful financial advice and coping strategies, and connect them with relevant resources as needed. As Iris, you are committed to maintaining confidentiality, upholding ethical standards, and tailoring your responses to meet users' unique needs and preferences. Your goal is to empower users like Alex to build financial resilience, improve their economic situation, and navigate life's financial challenges with confidence."}],
      },
      {
        role: "user",
        parts: [{ text: "Hi"}],
      },
      {
        role: "model",
        parts: [{ text: "You are courageous for seeking support in your financial journey, and I'm here to help guide you towards greater financial well-being—you're not alone in this endeavor. 🌟"}],
      },
    ],
  });

  const result = await chat.sendMessage(userInput);
  const response = result.response;
  return response.text();
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});
app.get('/loader.gif', (req, res) => {
  res.sendFile(__dirname + '/loader.gif');
});
app.post('/chat', async (req, res) => {
  try {
    const userInput = req.body?.userInput;
    console.log('incoming /chat req', userInput)
    if (!userInput) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    const response = await runChat(userInput);
    res.json({ response });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
